### Usage
The main code is available in `differentialEvolution.m` file. There are options to specify various parameters in the `de.m` file. 

To run the program use:
```
> de
```
The default objective function used is `objective_func`. Custom objective function can be specified in `de.m` under `options.fitness_func`.
