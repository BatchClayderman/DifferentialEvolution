rand_seed
de
draw